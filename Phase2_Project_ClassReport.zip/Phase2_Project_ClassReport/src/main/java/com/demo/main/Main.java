package com.demo.main;

import java.util.Set;

import org.hibernate.HibernateException;
import org.hibernate.Transaction;

 

import org.hibernate.Session;


import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import com.dxc.models.Students;
import com.dxc.HibernateUtil;

public class Main {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
	
		Transaction transaction = null;
	
		try {

		transaction = session.beginTransaction();
		Students student1 = new Students(97,"divya","tenth","maths","kavitha");
		Students student2 = new Students(95,"sravanthi","tenth","maths","kavitha");
		Students student3 = new Students(106,"sasha","eleventh","hindi","joon");
		Students student4 = new Students(107,"kim","eleventh","maths","joon");
		Students student5 = new Students(108,"jin","tenth","maths","lakshmi");
		Students student6 = new Students(109,"jk","ninth","maths","lakshmi");
		Students student7 = new Students(110,"jimin","ninth","maths","sahithi");
		Students student8 = new Students(111,"suma","eleventh","maths","sahithi");
		Students student9 = new Students(114,"kalyan","tenth","maths","sid");
		Students student10 = new Students(115,"vasu","tenth","maths","sid");
		
	
		session.save(student1);
		session.save(student2);
		session.save(student3);
		session.save(student4);
		session.save(student5);
		session.save(student6);
		session.save(student7);
		session.save(student8);
		session.save(student9);
		session.save(student10);
		transaction.commit();
		
		} catch (HibernateException e) {
		
		transaction.rollback();
		
		e.printStackTrace();
		
		} finally {
	
		session.close();

		}
	
	
		}
		}
		
		 
	    
		