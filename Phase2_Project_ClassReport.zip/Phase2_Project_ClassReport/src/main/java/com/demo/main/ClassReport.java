package com.demo.main;


import java.util.Set;

import org.hibernate.HibernateException;
import org.hibernate.Transaction;

 

import org.hibernate.Session;


import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import com.dxc.models.Progress;
import com.dxc.HibernateUtil;

public class ClassReport {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		
		Transaction transaction = null;
	
		try {

		transaction = session.beginTransaction();
	    Progress p1=new Progress(1,"tenth",11,6,6);
	    
	    Progress p2=new Progress(2,"eigth",7,6,6);
	   Progress p3=new Progress(3,"seventh",5,6,6);
	    Progress p4=new Progress(4,"sixth",2,6,6);
	    
	    session.save(p1);
	    session.save(p2);
	    session.save(p3);
	    session.save(p4);
	    transaction.commit();
	    
		} catch (HibernateException e) {
			
			transaction.rollback();
			
			e.printStackTrace();
			
			} finally {
		
			session.close();

			}
		
		
			}
			}
			
